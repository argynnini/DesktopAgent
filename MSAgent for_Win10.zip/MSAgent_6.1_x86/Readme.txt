How to Install
1. Copy "MSAgent" folder into C:\WINDOWS
2. Double-click in "MSAgent.reg" registry files
3. enjoy

Microsoft Agent 2.0 Copyright by Microsoft
Deployed and Repackaged by Agung Indra Saputra
michael_bryan_97@yahoo.com